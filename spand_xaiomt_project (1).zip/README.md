# SPAND-XAIoMT
Run: `pip install pandas scikit-learn joblib shap lime` then `python generate_data.py` (skip if you have real data in data/heart_wearable_raw.csv) and `python pipeline.py`.
pipeline.py cleans the data, compares 4 models, explains with SHAP + LIME and writes results.json. Re-embed results.json into dash_template.html (replace __DATA__) to refresh the dashboard.
Objectives: RO1 model training, RO2 4-model comparison table, RO3 SHAP+LIME, RO4 global feature ranking.
Real wearable data: export with the same column names (age, sex, bmi, smoker, resting_hr, hrv_sdnn, spo2, body_temp, systolic_bp, diastolic_bp, daily_steps, ecg_st_deviation, cholesterol, glucose, heart_disease).
