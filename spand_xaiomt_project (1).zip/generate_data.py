"""Simulated wearable/IoMT heart dataset (12,000 records) with realistic dirt:
missing values, sensor glitches, duplicates. Replace data/heart_wearable_raw.csv
with real wearable exports (same column names) to retrain on real data."""
import numpy as np, pandas as pd
rng = np.random.default_rng(42); N = 12000
age = rng.normal(52, 13, N).clip(20, 90).round()
sex = rng.integers(0, 2, N)                      # 1 = male
bmi = rng.normal(27, 4.5, N).clip(16, 48)
smoker = rng.binomial(1, 0.22, N)
sbp = (105 + 0.6*(age-20)*0.5 + 0.9*(bmi-22) + rng.normal(0, 11, N)).clip(85, 210)
dbp = (0.55*sbp + rng.normal(8, 6, N)).clip(50, 125)
chol = (165 + 0.7*(age-20) + 1.2*(bmi-22) + rng.normal(0, 30, N)).clip(110, 400)
glucose = (88 + 0.25*(age-20) + 0.8*(bmi-22) + rng.normal(0, 14, N)).clip(60, 300)
activity = (9500 - 70*(age-20) - 90*(bmi-22) + rng.normal(0, 2200, N)).clip(300, 20000)
rhr = (62 + 0.25*(bmi-22) + 0.08*(age-20) - activity/1800 + 3*smoker + rng.normal(0, 6, N)).clip(42, 130)
hrv = (70 - 0.55*(age-20) - 0.7*(rhr-60) + rng.normal(0, 9, N)).clip(8, 120)
temp = rng.normal(36.7, 0.3, N).clip(35.2, 38.5)
st = np.abs(rng.normal(0.3, 0.35, N))
spo2 = (98.2 - 0.02*(age-20) - 0.8*smoker + rng.normal(0, 1.1, N)).clip(84, 100)
z = (-3.9 + 0.045*age + 0.5*sex + 0.018*(sbp-120) + 0.008*(chol-190) + 0.007*(glucose-95)
     + 0.03*(rhr-65) - 0.025*(hrv-45) - 0.00018*(activity-6000) - 0.16*(spo2-97)
     + 1.9*st + 0.55*smoker + 0.03*(bmi-26) + rng.normal(0, 0.6, N))
y = rng.binomial(1, 1/(1+np.exp(-z)))
df = pd.DataFrame(dict(age=age, sex=sex, bmi=bmi, smoker=smoker, resting_hr=rhr, hrv_sdnn=hrv,
    spo2=spo2, body_temp=temp, systolic_bp=sbp, diastolic_bp=dbp, daily_steps=activity,
    ecg_st_deviation=st, cholesterol=chol, glucose=glucose, heart_disease=y)).round(2)
for c in ['spo2','hrv_sdnn','cholesterol','glucose','body_temp','ecg_st_deviation']:   # missing
    df.loc[rng.random(N) < 0.04, c] = np.nan
g = rng.random(N) < 0.01; df.loc[g, 'resting_hr'] = rng.choice([0, 250, 300], g.sum())  # sensor glitches
g = rng.random(N) < 0.008; df.loc[g, 'spo2'] = rng.choice([0, 55, 140], g.sum())
df = pd.concat([df, df.sample(150, random_state=1)], ignore_index=True)                    # duplicates
df.to_csv('data/heart_wearable_raw.csv', index=False); print(df.shape, df.heart_disease.mean().round(3))
