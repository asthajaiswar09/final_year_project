"""SPAND-XAIoMT pipeline: clean -> train/compare (RO1, RO2) -> SHAP + LIME (RO3) -> feature ranking (RO4).
Uses the real `shap` and `lime` packages when installed (pip install shap lime); otherwise falls back to
built-in model-agnostic implementations of the same two algorithms."""
import json, numpy as np, pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score, recall_score, precision_score
rng = np.random.default_rng(0)

# ---------- 1. CLEAN ----------
raw = pd.read_csv('data/heart_wearable_raw.csv'); log = {'raw_rows': len(raw)}
df = raw.drop_duplicates().copy(); log['duplicates_removed'] = len(raw) - len(df)
valid = {'resting_hr': (35, 200), 'spo2': (80, 100), 'body_temp': (34, 42), 'systolic_bp': (70, 250),
         'diastolic_bp': (40, 150), 'hrv_sdnn': (5, 200), 'daily_steps': (0, 40000)}
bad = 0
for c, (lo, hi) in valid.items():
    m = (df[c] < lo) | (df[c] > hi); bad += int(m.sum()); df.loc[m, c] = np.nan
log['sensor_glitches_nulled'] = bad
FEATS = [c for c in df.columns if c != 'heart_disease']
log['missing_before_impute'] = int(df[FEATS].isna().sum().sum())
df[FEATS] = df[FEATS].fillna(df[FEATS].median())          # median imputation
for c in ['cholesterol', 'glucose', 'bmi']:                # winsorise 0.5-99.5%
    df[c] = df[c].clip(*df[c].quantile([.005, .995]))
log['clean_rows'] = len(df); log['prevalence'] = round(df.heart_disease.mean(), 3)
df.to_csv('data/heart_wearable_clean.csv', index=False)

# ---------- 2. TRAIN & COMPARE (RO1, RO2) ----------
X, y = df[FEATS], df.heart_disease
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, stratify=y, random_state=42)
sc = StandardScaler().fit(Xtr)
models = {'Logistic Regression': LogisticRegression(max_iter=2000),
          'Random Forest': RandomForestClassifier(300, min_samples_leaf=5, n_jobs=-1, random_state=0),
          'Gradient Boosting': GradientBoostingClassifier(random_state=0),
          'Neural Network (MLP)': MLPClassifier((64, 32), max_iter=400, early_stopping=True, random_state=0)}
comp = []
for n, m in models.items():
    m.fit(sc.transform(Xtr), ytr); p = m.predict_proba(sc.transform(Xte))[:, 1]; pr = (p >= .5).astype(int)
    comp.append(dict(model=n, auc=roc_auc_score(yte, p), accuracy=accuracy_score(yte, pr),
                     precision=precision_score(yte, pr), recall=recall_score(yte, pr), f1=f1_score(yte, pr)))
comp = sorted(comp, key=lambda r: -r['auc']); best = comp[0]['model']; model = models[best]
print(pd.DataFrame(comp).round(4).to_string(index=False)); print('BEST:', best)
joblib.dump(dict(model=model, scaler=sc, feats=FEATS), 'model.joblib')
predict = lambda A: model.predict_proba(sc.transform(pd.DataFrame(A, columns=FEATS)))[:, 1]

# ---------- 3. EXPLAINERS (RO3) ----------
bg = Xtr.sample(100, random_state=1).values
try:
    import shap
    ex = shap.Explainer(predict, bg); shap_vals = lambda x: ex(x.reshape(1, -1)).values[0]; SH = 'shap'
except ImportError:                       # permutation-sampling Shapley values (same quantity SHAP estimates)
    SH = 'built-in sampling Shapley'
    def shap_vals(x, n=60):
        phi = np.zeros(len(x)); B = bg[rng.integers(0, len(bg), n)]
        for b in B:
            order = rng.permutation(len(x)); cur = b.copy(); prev = predict(cur[None])[0]
            for j in order:
                cur[j] = x[j]; nxt = predict(cur[None])[0]; phi[j] += nxt - prev; prev = nxt
        return phi / n
try:
    from lime.lime_tabular import LimeTabularExplainer
    le = LimeTabularExplainer(Xtr.values, feature_names=FEATS, class_names=['Normal', 'At Risk'], discretize_continuous=False)
    def lime_vals(x):
        e = le.explain_instance(x, lambda A: np.c_[1 - predict(A), predict(A)], num_features=len(FEATS)).as_map()[1]
        o = np.zeros(len(FEATS)); [o.__setitem__(i, w) for i, w in e]; return o
    LM = 'lime'
except ImportError:                       # LIME algorithm: perturb, weight by proximity, fit local ridge
    LM = 'built-in LIME algorithm'; sd = Xtr.std().values
    def lime_vals(x, n=1500):
        Z = x + rng.normal(0, 1, (n, len(x))) * sd; Z[0] = x
        w = np.exp(-(((Z - x) / sd) ** 2).sum(1) / (0.75 * len(x)))
        r = Ridge(alpha=1.0).fit((Z - x) / sd, predict(Z), sample_weight=w)
        return r.coef_ * ((x - Xtr.mean().values) / sd)       # contribution relative to average patient
print('Explainers:', SH, '|', LM)

# ---------- 4. PATIENTS + GLOBAL FEATURES (RO4) ----------
te = Xte.copy(); te['p'] = predict(te.values)
picks = [te.p.sub(t).abs().idxmin() for t in (.06, .18, .45, .62, .80, .95)]
pats = []
for k, i in enumerate(picks):
    x = Xte.loc[i].values.astype(float); p = float(predict(x[None])[0])
    pats.append(dict(id=f'P-{1001+k}', risk=round(p * 100, 1), vals={f: round(float(v), 2) for f, v in zip(FEATS, x)},
                     shap=[round(float(v) * 100, 2) for v in shap_vals(x)], lime=[round(float(v) * 100, 2) for v in lime_vals(x)]))
S = Xte.sample(150, random_state=3).values; G = np.abs([shap_vals(s, 20) if SH != 'shap' else shap_vals(s) for s in S]).mean(0) * 100
glob = sorted(zip(FEATS, G.round(2).tolist()), key=lambda t: -t[1])
json.dump(dict(log=log, comparison=comp, best=best, feats=FEATS, patients=pats, global_importance=glob,
               explainers=[SH, LM], base=round(float(predict(bg).mean()) * 100, 1)), open('results.json', 'w'), indent=1)
print(log); print('Top features:', glob[:5])
