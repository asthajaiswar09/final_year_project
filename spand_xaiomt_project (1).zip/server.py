"""Live receiver: wearable -> POST /api/vitals -> model + SHAP -> dashboard (GET /).
Run: python server.py   (needs: pip install flask)"""
import json, time, sqlite3, joblib, numpy as np, pandas as pd
from flask import Flask, request, jsonify, send_file
app = Flask(__name__)
M = joblib.load('model.joblib'); model, sc, FEATS = M['model'], M['scaler'], M['feats']
clean = pd.read_csv('data/heart_wearable_clean.csv'); MED = clean[FEATS].median().to_dict()
bg = clean[FEATS].sample(100, random_state=1).values; rng = np.random.default_rng(0)
predict = lambda A: model.predict_proba(sc.transform(pd.DataFrame(A, columns=FEATS)))[:, 1]
try:
    import shap; _ex = shap.Explainer(predict, bg); explain = lambda x: _ex(x.reshape(1, -1)).values[0]
except ImportError:
    def explain(x, n=40):
        phi = np.zeros(len(x))
        for b in bg[rng.integers(0, len(bg), n)]:
            cur = b.copy(); prev = predict(cur[None])[0]
            for j in rng.permutation(len(x)):
                cur[j] = x[j]; nxt = predict(cur[None])[0]; phi[j] += nxt - prev; prev = nxt
        return phi / n
db = sqlite3.connect('vitals.db', check_same_thread=False)
db.execute('create table if not exists r(pid text, ts real, vals text, risk real, shap text)')
db.execute('create table if not exists prof(pid text primary key, vals text)'); db.commit()
LIVE = {'resting_hr', 'spo2', 'body_temp', 'daily_steps', 'hrv_sdnn', 'systolic_bp', 'diastolic_bp', 'ecg_st_deviation'}

@app.post('/api/profile')          # one-time: age, sex, bmi, smoker, cholesterol, glucose ...
def profile():
    d = request.get_json(force=True); pid = d.pop('patient_id', 'P-1001')
    db.execute('insert or replace into prof values(?,?)', (pid, json.dumps(d))); db.commit(); return jsonify(ok=True)

@app.post('/api/vitals')           # called by the wearable / phone app / ESP32
def vitals():
    d = request.get_json(force=True); pid = d.pop('patient_id', 'P-1001')
    p = db.execute('select vals from prof where pid=?', (pid,)).fetchone()
    v = {**MED, **(json.loads(p[0]) if p else {}), **{k: float(x) for k, x in d.items() if k in FEATS}}
    x = np.array([v[f] for f in FEATS], float); risk = float(predict(x[None])[0]) * 100
    sh = (explain(x) * 100).round(2).tolist()
    db.execute('insert into r values(?,?,?,?,?)', (pid, time.time(), json.dumps(v), risk, json.dumps(sh))); db.commit()
    return jsonify(risk=round(risk, 1))

@app.get('/api/latest')
def latest():
    pid = request.args.get('patient_id', 'P-1001')
    rows = db.execute('select ts,vals,risk,shap from r where pid=? order by ts desc limit 40', (pid,)).fetchall()
    if not rows: return jsonify(empty=True)
    ts, v, r, s = rows[0]
    return jsonify(ts=ts, vals=json.loads(v), risk=round(r, 1), shap=json.loads(s), feats=FEATS,
                   history=[dict(ts=a, risk=round(c, 1), hr=json.loads(b)['resting_hr']) for a, b, c, _ in rows[::-1]],
                   base=round(float(predict(bg).mean()) * 100, 1))

@app.get('/')
def home(): return send_file('live_dashboard.html')
if __name__ == '__main__': app.run(host='0.0.0.0', port=5000)
