"""Fake wearable for testing: python simulator.py  (server.py must be running)"""
import requests, time, random
U = 'http://localhost:5000/api'
requests.post(U + '/profile', json=dict(patient_id='P-1001', age=46, sex=1, bmi=26, smoker=0, cholesterol=195, glucose=98, systolic_bp=124, diastolic_bp=80))
hr = 78
while True:
    hr = max(55, min(125, hr + random.uniform(-4, 5)))
    r = requests.post(U + '/vitals', json=dict(patient_id='P-1001', resting_hr=round(hr), spo2=round(random.uniform(94, 99)),
        body_temp=round(random.uniform(36.4, 37.4), 1), daily_steps=random.randint(2000, 6000), hrv_sdnn=round(random.uniform(22, 45)),
        ecg_st_deviation=round(random.uniform(0.1, 1.2), 2)))
    print('sent HR', round(hr), '-> risk', r.json()['risk'], '%'); time.sleep(3)
